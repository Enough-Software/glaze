package de.enough.glaze.ui.delegate;

/**
 * An interface to extend {@link Screen} instances for the use in Glaze
 * 
 * @author Andre
 * 
 */
public interface GzScreen extends GzManager {

}
